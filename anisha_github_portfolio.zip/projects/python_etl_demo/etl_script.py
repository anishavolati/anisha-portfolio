# Sample ETL script using Python
print('Running ETL...')