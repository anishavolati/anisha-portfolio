-- Sample SQL for Snowflake
SELECT * FROM sales_data;