# 👩‍💻 Naga Suguna Anisha Volati – Data Engineer Portfolio

Welcome to my GitHub portfolio! I'm a Data Engineer with 7+ years of experience designing scalable data pipelines and analytics platforms across healthcare, finance, and semiconductor industries.

## 💼 About Me
- Skilled in Python, Java, SQL, Spark, and Airflow
- Cloud: AWS (S3, EMR, Glue), Azure, GCP
- Warehousing: Snowflake, Redshift, Athena
- Data Modeling: Star, Snowflake Schema, Data Vault
- Real-Time: Kafka, Redis, Spark Streaming
- API: RESTful, GraphQL

## 🧠 Key Projects
### Athenahealth (Healthcare)
- HIPAA-compliant pipeline for clinical, claims, and operational datasets
- Real-time alerts using Kafka + Snowflake Streams
- GraphQL APIs integrated into React-based dashboards

### Credit Acceptance (Finance)
- Lakehouse on AWS for loan & payment data
- Fraud detection via Spark Streaming & Kafka
- ML models for credit scoring and risk analytics

### AMD (Semiconductor)
- GPU telemetry ingestion using Airflow and Spark
- Predictive maintenance using Scikit-learn/TensorFlow
- Visualizations in Tableau & Matplotlib

## 📂 Repository Structure
- `/projects/python_etl_demo/` – Simple Python ETL example
- `/projects/airflow_dag_example/` – Sample Airflow DAG
- `/projects/sql_transformations/` – Sample SQL scripts (Snowflake/Athena)

## 📎 Resume
See [`Resume_Anisha_Volati.pdf`](./Resume_Anisha_Volati.pdf) for full background.

## 📬 Connect with Me
- Email: anishavolati@gmail.com
- LinkedIn: [Anisha's Profile](https://www.linkedin.com/in/naga-suguna-anisha-volati-08825427b/)

---

Thanks for visiting! ⭐
